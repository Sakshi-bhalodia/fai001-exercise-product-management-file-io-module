﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities
{
    /*
     * this serializable class models product data that includes product id, product name, price and in-stock status
     */

    public class Product
    {
        public int ProductId;
        public string ProductName;
        public float Price;
        public bool InStock;
        /*
        * define properties for Product model attributes 
        */



        /*
         * Override ToString() method to return string equivalent of product object containing product details
         */
        public override string ToString()
        {
            return $"Product Id: {ProductId} , Product Name : {ProductName} , Price : {Price}, In stock : {InStock}";
        }
    }
}
