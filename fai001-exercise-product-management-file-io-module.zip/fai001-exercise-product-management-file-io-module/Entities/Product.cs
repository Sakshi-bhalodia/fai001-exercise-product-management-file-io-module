﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities
{
    /*
     * this serializable class models product data that includes product id, product name, price and in-stock status
     */

    public class Product
    {
        public object productId;
        public object productName;
        public object price;

        /*
        * define properties for Product model attributes 
        */



        /*
         * Override ToString() method to return string equivalent of product object containing product details
         */
        public override string ToString()
        {
            return $"Product Id: {productId} , Product Name : {productName} , Price : {price}";
        }
    }
}
