﻿using Repositories;
using System;

namespace ProductModuleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * code here is not mandatory but will help 
             * to understand flow better
             */
            Console.WriteLine("Hello World");
        }
    }
}
