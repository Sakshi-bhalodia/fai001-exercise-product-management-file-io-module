﻿using System;
using System.Collections.Generic;

namespace Repositories1
{
    class Program
    {
        static void Main(string[] args)

        {
            Dictionary<int, string> D2 = new Dictionary<int, string>();

            ProductRepository product = new ProductRepository(10, "sakshi", D2);
            product.AddProduct("mug2", 1);
            product.AddProduct("mug", 10);

            product.AddProduct("watch", 3);
            product.AddProduct("pen", 4);
            product.AddProduct("book", 5);
            product.AddProduct("mouse", 6);
            if (product.RemoveProduct(1))
            {
                Console.WriteLine("Product found and Removed");
            }
            else
            {
                Console.WriteLine("Product not found");
            }
            if (product.GetProduct(2))
            {
                Console.WriteLine("Product found");

            }
            else
            {
                Console.WriteLine("No product found");
            }
            if (product.GetProduct(18))
            {
                Console.WriteLine("Product found");

            }
            else
            {
                Console.WriteLine("No product found");
            }
            if (product.GetProduct("noproduct"))
            {
                Console.WriteLine("Product found");

            }
            else
            {
                Console.WriteLine("No product found");
            }
            if (product.GetProduct("pen"))
            {
                Console.WriteLine("Product found");

            }
            else
            {
                Console.WriteLine("No product found");
            }

            foreach (var item in product.GetAllProducts())
            {
                Console.WriteLine($"Product id-{item.Key}, Product name-{item.Value}");
            }

            DataContext Data = new DataContext("DataContext.txt", @"C:\FAITraining");
            Console.WriteLine(Data.ReadProducts("DataContext.txt", @"C:\FAITraining"));
            Data.AddProduct(product.GetAllProducts(), 13, "glass");
            Data.SaveChanges(product.GetAllProducts());
            if (Data.CleanUp("Datacontext.txt", @"C:\FAITraining"))
            {
                Console.WriteLine("File deleted successfully");

            }
            else
            {
                Console.WriteLine("Couldnot find file");
            }
        }

    }
}
