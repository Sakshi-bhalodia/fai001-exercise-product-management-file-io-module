﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Repositories1
{
    // this class provides functionalities to read and write product collection data with file

    public class DataContext
    {
        // declare field for filename with path
        // declare field for list of products
        public string filename { get; set; }
        public string pathstrings { get; set; }


        // the constructor should accept filename and path strings
        public DataContext(string filename, string pathstrings)
        {
            // the constructor code should open file if it exists else create new

            // the code should read data from file if it contains any data

            // the data read should populate the list of products field

            // if no data is present an empty list should be created 
            if (!File.Exists($@"{pathstrings}\{filename}"))
            {
                File.Create($@"{pathstrings}\{filename}");
            }
            StreamReader filer = new StreamReader($@"{pathstrings}\{filename}");
            var contents = filer.ReadToEnd();
            Console.WriteLine($"initial data- {contents}");
            filer.Close();

        }

        // this method should return the list of products read from file
        public string ReadProducts(string filename, string pathstrings)
        {
            // return data of the product list
            var content = File.ReadAllText($@"{pathstrings}\{filename}");
            Console.WriteLine(content);
            StreamReader filer = new StreamReader($@"{pathstrings}\{filename}");
            var contents = filer.ReadToEnd();
            Console.WriteLine($"initial data-data{contents}");
            return contents;
        }

        // this method should add the product data passed as parameter to the list of products
        public void AddProduct(Dictionary<int, string> D2, int id, string name)
        {
            D2.Add(id, name);
        }

        // this method should write the data from list of products to file and make data persistent
        public void SaveChanges(Dictionary<int, string> D2)
        {
            // implement serialization
            StreamWriter filew = new StreamWriter(@"C:\FAITraining\fai001-exercise-product-management-file-io-module\DataContext.txt", true);
            foreach (var i in D2)
            {
                filew.WriteLine($"Product id-{i.Key} Product Name-{i.Value}");
            }
            filew.Close();
        }

        // this method should delete the file if exists
        public bool CleanUp(string filename, string pathstrings)
        {
            if (File.Exists($@"{pathstrings}\{filename}"))
            {
                File.Delete($@"{pathstrings}\{filename}");
                return true;
            }
            else
                return false;
        }
    }
}
