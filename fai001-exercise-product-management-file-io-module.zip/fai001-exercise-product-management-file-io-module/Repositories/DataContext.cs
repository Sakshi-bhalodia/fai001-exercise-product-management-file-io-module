using Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace Repositories
{
    // this class provides functionalities to read and write product collection data with file

    public class DataContext
    { 
        // declare field for filename with path
        // declare field for list of products
        public string filename { get; set; }
        public string pathstrings { get; set;}


        // the constructor should accept filename and path strings
        public DataContext(string filename,string pathstrings)
        {
            // the constructor code should open file if it exists else create new

            // the code should read data from file if it contains any data

            // the data read should populate the list of products field

            // if no data is present an empty list should be created 
            if(!File.Exists($@"{pathstrings}\{filename}"))
            {
                File.Create($@"{pathstrings}\{filename}");
            }
            StreamReader file = new StreamReader($@"{pathstrings}\{filename}");
            var contents = file.ReadToEnd();
            Console.WriteLine($"initial data- {contents}");
            file.Close();
            
        }

        // this method should return the list of products read from file
        public string ReadProducts(string filename,string pathstrings)
        {
            // return data of the product list
            var content = File.ReadAllText($@"{pathstrings}\{filename}");
            Console.WriteLine(content);
            StreamReaderfile= new StreamReader($@"{pathstrings}\{filename}");
            var contents = file.ReadToEnd();
            Console.WriteLine($"initial data-data{contents}");
            return contents;
        }

        // this method should add the product data passed as parameter to the list of products
        public void AddProduct(Dictionary<int,string> dict2,int id,string name)
        {
            dict2.Add(id, name);            
        }

        // this method should write the data from list of products to file and make data persistent
        public void SaveChanges(Dictionary<int, string> dict2)
        {
            // implement serialization
            StreamWriter file2 = new StreamWriter(@"C:\FAITraining\fai001-exercise-product-management-file-io-module\DataContext.txt", true);
            foreach(var i in dict2)
            {
                file2.WriteLine($"Product id-{i.Key} Product Name-{i.Value}");
            }
            file2.Close();
        }

        // this method should delete the file if exists
        public bool CleanUp(string filename, string pathstrings)
        {
            if (File.Exists($@"{pathstrings}\{filename}"))
            {
                File.Delete($@"{pathstrings}\{filename}");
                return true;
            }
            else
                return false;
        }
    }
}
