﻿using Entities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Repositories
{
    public class ProductRepository
    {
        // declare field of type DataContext
        public string {get;set;}
        public interface id { get; set;}
    Dictionary<int, string> dict = new Dictionary<int, string>();


        public ProductRepository(<int id,string name,Dictionary<int,string> dict)
       
        {
        //initialize the DataContext field with parameter passed \
            this.id = id;
            this.name = name;
            this.dict = dict;
        }

        /*
         * this method should accept product data and add it to the product collection
         * 
         */
        public <return_type> AddProduct(string name,int id)
        {
        // code to add product to file, ensuring that product is not null
            dict.Add(id, name);
        }


        /*
         * this method should search for the product by the provided product id 
         * and if found should remove it from the collection
         * 
         * the method should return true for success and false for invalid id 
         */
        public bool RemoveProduct(int id)
        {
        // code to remove product by the id provided from file as parameter
        if (dict.ContainsKEy(id))
        {
            dict.Remove(id);
            return true;
        }
        else 
            return false;
        }

        /*
         * this method should search and return product by product name from the file 
         * 
         * the search value should be passed as parameter
         * 
         * the method should return null for non-matching product name
         */
        public bool GetProduct(string name)
        {
        if (dict.ContainsValue(name))
            return true;
        else
            return false;
        }

        /*
         * this method should search and return product by product id from the collection 
         * 
         * the search value should be passed as parameter
         * 
         * the method should return null for non-matching product id
         */
        public bool GetProduct(int id)
        {
        if (dict.ContainsKey(id))
            return true;
        else
            return false;
        }

        
        /*
         * this method should return all items from the product collection
         */
        public <return_type> GetAllProducts()
        {

        }
    }
}
